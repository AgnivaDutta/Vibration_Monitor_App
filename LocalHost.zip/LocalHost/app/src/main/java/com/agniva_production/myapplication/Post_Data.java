package com.agniva_production.myapplication;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Post_Data extends Service {

    String X, Y, Z;
    String currentDateandTime;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //Toast.makeText(getApplicationContext(), "Starting the POST service", Toast.LENGTH_SHORT).show();


        X = intent.getExtras().get("X").toString();
        Y = intent.getExtras().get("Y").toString();
        Z = intent.getExtras().get("Z").toString();
        currentDateandTime = intent.getExtras().get("DT").toString();

        URL url = null;
        String text = "";
        BufferedReader reader =null;

        try{

            Log.d("Debug", "Inside the Post try block");
            url = new URL("http://192.168.0.107/Bridge_Monitor/receiver.php");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(urlConnection.getOutputStream());

            String datam = URLEncoder.encode("x", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(X), "UTF-8");
            datam += "&" + URLEncoder.encode("y", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(Y), "UTF-8");
            datam += "&" + URLEncoder.encode("z", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(Z), "UTF-8");
            datam += "&" + URLEncoder.encode("datetime", "UTF-8") + "=" + URLEncoder.encode(currentDateandTime, "UTF-8");
            datam += "&" + URLEncoder.encode("place", "UTF-8") + "=" + URLEncoder.encode(StorageData.location, "UTF-8");



            wr.write( datam );
            wr.flush();
            Log.d("Debug", "Data Written");


            reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while((line = reader.readLine()) != null)
            {
                // Append server response in string
                sb.append(line + "\n");
            }
            text = sb.toString();
        } catch(Exception e){}
        finally
        {
            try
            {

                reader.close();
            }

            catch(Exception ex) {}
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        //Toast.makeText(getApplicationContext(), "Exiting the POST service", Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }
}
