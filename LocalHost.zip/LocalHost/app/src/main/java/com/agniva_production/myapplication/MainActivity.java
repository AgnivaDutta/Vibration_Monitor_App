package com.agniva_production.myapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    BluetoothAdapter mBluetoothAdapter;
    BluetoothDevice mDevice;
    Spinner spinner;
    Button connectButton;
    ConnectThread mConnectThread;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);

        connectButton = findViewById(R.id.connect);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(), "Sorry!, Bluetooth service is not available", Toast.LENGTH_LONG).show();
            finish();
        }

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new
                    Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }else{
            proceed();
        }
    }

    private void proceed(){
        final Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

        List<String> list = new ArrayList<String>();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                list.add(device.getName());
                //mDevice = device;
            }
        }
        else{
            list.add("No paired device. Please pair with the module first");
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        spinner.setAdapter(adapter);
        spinner.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Iterator<BluetoothDevice> iterator= pairedDevices.iterator();
                int count=0;
                while(count<position)
                {
                    iterator.next();
                    count++;
                }
                mDevice = iterator.next();
                Toast.makeText(getApplicationContext(), mDevice.getName()+" Selected Now", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mConnectThread = new ConnectThread(mDevice);
                mConnectThread.start();
            }
        });
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;
        private final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

        public ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            mmDevice = device;
            try
            {
                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
            }
            catch (IOException e) { }
            mmSocket = tmp;
        }
        public void run() {
            mBluetoothAdapter.cancelDiscovery();
            Log.d("Debug", "ConnectThread Started");
            try
            {
                mmSocket.connect();
            }
            catch (IOException connectException) {
                Log.d("Debug", "IOException");
                try
                {
                    mmSocket.close();
                }
                catch (IOException closeException) { }
                return;
            }
            Log.d("Debug", "Succesfully connected");

            StorageData.mmSocket = mmSocket;
            StorageData.mBluetoothAdapter = mBluetoothAdapter;
            StorageData.mDevice = mDevice;
            Intent i = new Intent(getApplicationContext(), Main2Activity.class);
            startActivity(i);

        }
        public void cancel() {
            try
            {
                mmSocket.close();
            }
            catch (IOException e) { }
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 1)
        {
            if(resultCode == RESULT_OK)
            {
                proceed();
            }
            else {
                Toast.makeText(getApplicationContext(), "Sorry!, Bluetooth service is requied for this app", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }



    private void end(){
        Toast.makeText(this, "Disabling the adapter", Toast.LENGTH_SHORT).show();
        mBluetoothAdapter.disable();
        AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
        ab.setTitle("Thanks you");
        final TextView tv = new TextView(MainActivity.this);
        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        tv.setText("Thank you for using the application");
        ab.setView(tv);
        ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        ab.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                return;
            }
        });
        AlertDialog ad = ab.create();
        ad.show();
    }

    @Override
    protected void onDestroy() {
        end();
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.changeNo){
            AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
            ab.setTitle("Enter new Phone number below");
            final EditText et = new EditText(MainActivity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(et.getText().toString().equals("") || et.getText() == null){
                        //Do nothing. Previous value persists.
                    }else{
                        if(TextUtils.isDigitsOnly(et.getText())){
                            StorageData.phone_number = et.getText().toString();
                        }else{
                            //Do nothing. Previous value persists.
                            Toast.makeText(getApplicationContext(), "Please enter a valid number", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
            AlertDialog ad = ab.create();
            ad.show();

        }else if(item.getItemId() == R.id.changeUrl){
            AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
            ab.setTitle("Enter new POST URL below");
            final EditText et = new EditText(MainActivity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(et.getText().toString().equals("") || et.getText() == null){
                        //Do nothing. Previous value persists.
                    }else{
                        StorageData.PostURL = et.getText().toString();
                    }
                }
            });
            AlertDialog ad = ab.create();
            ad.show();
        }else if(item.getItemId() == R.id.changeLoc){
            AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
            ab.setTitle("Enter new bridge location below");
            final EditText et = new EditText(MainActivity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(et.getText().toString().equals("") || et.getText() == null){
                        //Do nothing. Previous value persists.
                    }else{
                        StorageData.location = et.getText().toString();
                    }
                }
            });
            AlertDialog ad = ab.create();
            ad.show();
        }else if(item.getItemId() == R.id.exit){
            end();
        }
        return super.onOptionsItemSelected(item);
    }

}


