package com.agniva_production.myapplication;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main2Activity extends AppCompatActivity {

    ConnectedThread mConnectedThread;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothDevice mDevice;
    private BluetoothSocket mmSocket;

    private boolean messageEnable = true;

    TextView txtX, txtY, txtZ;

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mBluetoothAdapter = StorageData.mBluetoothAdapter;
        mDevice = StorageData.mDevice;
        mmSocket = StorageData.mmSocket;

        txtX = findViewById(R.id.txtX);
        txtY = findViewById(R.id.txtY);
        txtZ = findViewById(R.id.txtZ);


        Toast.makeText(getApplicationContext(), "Starting ConnectedThread", Toast.LENGTH_SHORT).show();
        mConnectedThread = new ConnectedThread(mmSocket);
        mConnectedThread.start();
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }
            mmInStream = tmpIn;
            mmOutStream = tmpOut;
            Toast.makeText(getApplicationContext(), "Streams Initiated", Toast.LENGTH_SHORT).show();
        }
        public void run() {
            byte[] buffer = new byte[1024];
            int begin = 0;
            int bytes = 0;
            while (true) {
                try {
                    bytes += mmInStream.read(buffer, bytes, buffer.length - bytes);
                    for(int i = begin; i < bytes; i++) {
                        if(buffer[i] == "#".getBytes()[0]) {
                            mHandler.obtainMessage(1, begin, i, buffer).sendToTarget();
                            begin = i + 1;
                            if(i == bytes - 1) {
                                bytes = 0;
                                begin = 0;
                            }
                        }
                    }

                } catch (IOException e) {
                    break;
                }
            }
        }
        public void write(byte[] bytes) {
            try {
                mmOutStream.write(bytes);
            } catch
                    (IOException e) { }
        }
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            byte[] writeBuf = (byte[]) msg.obj;
            int begin = (int)msg.arg1;
            int end = (int)msg.arg2;
            switch(msg.what) {
                case 1: String writeMessage = new String(writeBuf);
                    writeMessage = writeMessage.substring(begin, end);

                    String data = writeMessage.toString();
                    String s[] = data.split(";");
                    int X, Y, Z;
                    try{
                        X = Integer.parseInt(s[0]);
                        Y = Integer.parseInt(s[1]);
                        Z = Integer.parseInt(s[2]);

                        txtX.setText(s[0]);
                        txtY.setText(s[1]);
                        txtZ.setText(s[2]);
                    }catch (Exception e){return;}


                    if(X>1600 || Y>700 || Z>800)
                    {
                        if(messageEnable){
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
                            String currentDateandTime = sdf.format(new Date());
                            int permissionCheck = ContextCompat.checkSelfPermission(Main2Activity.this, Manifest.permission.SEND_SMS);
                            if(permissionCheck == PackageManager.PERMISSION_GRANTED){
                                String phoneNo = StorageData.phone_number;
                                String message = "Excessive vibration occured in" + StorageData.location + " . The data are X="+X+" Y="+Y+"Z="+Z+" and the date and time of incident is = "+currentDateandTime;
                                if(phoneNo == null || phoneNo.equals("")){ }
                                else{
                                    if(TextUtils.isDigitsOnly(phoneNo)){
                                        SmsManager smsManager = SmsManager.getDefault();
                                        smsManager.sendTextMessage(phoneNo, null, message, null, null);
                                        Toast.makeText(getApplicationContext(), "Error report sent", Toast.LENGTH_SHORT).show();
                                    }
                                    else{
                                        Toast.makeText(getApplicationContext(), "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }else{
                                ActivityCompat.requestPermissions(Main2Activity.this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
                            }

                            Intent t = new Intent(getApplicationContext(), Post_Data.class);
                            t.putExtra("X", X);
                            t.putExtra("Y", Y);
                            t.putExtra("Z", Z);
                            t.putExtra("DT", currentDateandTime);
                            startService(t);



                        }
                    }

                    break;
            }
        }
    };



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case MY_PERMISSIONS_REQUEST_SEND_SMS:
            {
                if(grantResults.length>=0 && grantResults[0]==PackageManager.PERMISSION_DENIED){
                    Toast.makeText(getApplicationContext(), "The send permission is necessary for the app", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.changeNo){
            AlertDialog.Builder ab = new AlertDialog.Builder(Main2Activity.this);
            ab.setTitle("Enter new Phone number below");
            final EditText et = new EditText(Main2Activity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(et.getText().toString().equals("") || et.getText() == null){
                        //Do nothing. Previous value persists.
                    }else{
                        if(TextUtils.isDigitsOnly(et.getText())){
                            StorageData.phone_number = et.getText().toString();
                        }else{
                            //Do nothing. Previous value persists.
                            Toast.makeText(getApplicationContext(), "Please enter a valid number", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
            AlertDialog ad = ab.create();
            ad.show();

        }else if(item.getItemId() == R.id.changeUrl){
            AlertDialog.Builder ab = new AlertDialog.Builder(Main2Activity.this);
            ab.setTitle("Enter new POST URL below");
            final EditText et = new EditText(Main2Activity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(et.getText().toString().equals("") || et.getText() == null){
                        //Do nothing. Previous value persists.
                    }else{
                        StorageData.PostURL = et.getText().toString();
                    }
                }
            });
            AlertDialog ad = ab.create();
            ad.show();
        }else if(item.getItemId() == R.id.changeLoc){
            AlertDialog.Builder ab = new AlertDialog.Builder(Main2Activity.this);
            ab.setTitle("Enter new bridge location below");
            final EditText et = new EditText(Main2Activity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(et.getText().toString().equals("") || et.getText() == null){
                        //Do nothing. Previous value persists.
                    }else{
                        StorageData.location = et.getText().toString();
                    }
                }
            });
            AlertDialog ad = ab.create();
            ad.show();
        }else if(item.getItemId() == R.id.exit){
            mBluetoothAdapter.disable();
            AlertDialog.Builder ab = new AlertDialog.Builder(Main2Activity.this);
            ab.setTitle("Thanks you");
            final TextView tv = new TextView(Main2Activity.this);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setText("Thank you for using the application");
            ab.setView(tv);
            ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //Do nothing. Just to greet the user.
                }
            });
            AlertDialog ad = ab.create();
            ad.show();
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
