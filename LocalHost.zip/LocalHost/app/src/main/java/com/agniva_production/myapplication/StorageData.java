package com.agniva_production.myapplication;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

public class StorageData {

    public static BluetoothSocket mmSocket;
    public static BluetoothAdapter mBluetoothAdapter;
    public static BluetoothDevice mDevice;
    public static String phone_number = "9433084361";
    public static String location = "Undefined Bridge";
    public static String PostURL = "";

}
